class Aluno:
  nome = None
  cpf = 0
  peso = 0
  altura = 0


class Exercicio:
  nomeAluno = None
  nomeExercicio = None
  numRepeticoes = 0
  pesoExercicio = 0


cadAlunos = []  # lista de alunos
treinoAlunos = []  # matriz de treinos


def cabecalho():
  print("******************************")
  print("---Welcome to DD Fitness---")
  print('******************************')


cabecalho()

# fonte Stake overflow
def validar_cpf(cpf):
    cpf = cpf.replace(".", "").replace("-", "")  # Remove os pontos e traços do CPF
    if len(cpf) != 11 or not cpf.isdigit():  # Verifica se o CPF possui 11 dígitos numéricos
        return False

    # Verifica se todos os dígitos são iguais (caso contrário, seria um CPF inválido)
    if len(set(cpf)) == 1:
        return False

    # Validação do primeiro dígito verificador
    soma = sum(int(cpf[i]) * (10 - i) for i in range(9))
    resto = (soma * 10) % 11
    if resto == 10 or resto == int(cpf[9]):
        pass
    else:
        return False

    # Validação do segundo dígito verificador
    soma = sum(int(cpf[i]) * (11 - i) for i in range(10))
    resto = (soma * 10) % 11
    if resto == 10 or resto == int(cpf[10]):
        return True
    else:
        return False

def cadastrar():
    aluno = Aluno()  # Cria um novo objeto Aluno
    aluno.nome = input("Nome do aluno: ")  # Solicita o nome do aluno ao usuário e atribui ao atributo 'nome' do objeto aluno
    cpf_valido = False
    while not cpf_valido:
        aluno.cpf = input("CPF do aluno: ")  # Solicita o CPF do aluno ao usuário e atribui ao atributo 'cpf' do objeto aluno
        cpf_valido = validar_cpf(aluno.cpf)  # Verifica se o CPF é válido usando a função 'validar_cpf'
        if not cpf_valido:
            print("CPF inválido. Por favor, insira um CPF válido.")  # Exibe uma mensagem de CPF inválido se o CPF não for válido
    aluno.peso = float(input("Peso do aluno: "))  # Solicita o peso do aluno ao usuário e converte para float, atribuindo ao atributo 'peso' do objeto aluno
    aluno.altura = float(input("Altura do aluno: "))  # Solicita a altura do aluno ao usuário e converte para float, atribuindo ao atributo 'altura' do objeto aluno
    cadAlunos.append(aluno)  # Adiciona o objeto aluno à lista 'cadAlunos' que contém os registros dos alunos
    print("Aluno esta cadastrado com sucessso")


def consultar():
  nome_consulta = input("Digite o nome do aluno para consultar: ")  # Solicita o nome do aluno para consulta
  resultados = []  # Lista para armazenar os resultados da consulta
  for aluno in cadAlunos:  # Percorre todos os alunos cadastrados
    if aluno.nome == nome_consulta:  # Verifica se o nome do aluno corresponde à consulta
      resultados.append(aluno)  # Adiciona o aluno encontrado à lista de resultados

  if len(resultados) == 0:  # Verifica se não foram encontrados alunos com o nome informado
    print("Nenhum aluno encontrado com esse nome.")
  else:
    print("Alunos encontrados:")
    for aluno in resultados:  # Percorre a lista de resultados e exibe as informações de cada aluno
      print("Nome:", aluno.nome)
      print("CPF:", aluno.cpf)
      print("Peso:", aluno.peso)
      print("Altura:", aluno.altura)
      print()  # Imprime uma linha em branco para separar as informações de cada aluno


def atualizar():
  nome_aluno = input("Digite o nome do aluno para atualizar o cadastro: ")  # Solicita o nome do aluno para atualização
  alunos_encontrados = []  # Lista para armazenar os alunos encontrados com o nome informado
  for aluno in cadAlunos:  # Percorre todos os alunos cadastrados
    if aluno.nome == nome_aluno:  # Verifica se o nome do aluno corresponde à busca
      alunos_encontrados.append(aluno)  # Adiciona o aluno encontrado à lista de alunos encontrados

  if len(alunos_encontrados) == 0:  # Verifica se não foram encontrados alunos com o nome informado
    print("Nenhum aluno encontrado com esse nome.")
    return

  print("Alunos encontrados:")
  for aluno in alunos_encontrados:  # Percorre a lista de alunos encontrados e exibe suas informações
    print("Nome:", aluno.nome)
    print("CPF:", aluno.cpf)
    print("Peso:", aluno.peso)
    print("Altura:", aluno.altura)
    print()

  novo_nome = input("Digite o novo nome (ou deixe em branco para manter o mesmo): ")  # Solicita o novo nome para atualização
  novo_cpf = input("Digite o novo CPF (ou deixe em branco para manter o mesmo): ")  # Solicita o novo CPF para atualização
  novo_peso = input("Digite o novo peso (ou deixe em branco para manter o mesmo): ")  # Solicita o novo peso para atualização
  nova_altura = input("Digite a nova altura (ou deixe em branco para manter a mesma): ")  # Solicita a nova altura para atualização

  for aluno in alunos_encontrados:  # Percorre a lista de alunos encontrados e atualiza seus atributos com as novas informações
    if novo_nome != "":
      aluno.nome = novo_nome
    if novo_cpf != "":
      aluno.cpf = novo_cpf
    if novo_peso != "":
      aluno.peso = float(novo_peso)
    if nova_altura != "":
      aluno.altura = float(nova_altura)

  print("Cadastro dos alunos atualizado com sucesso.")  # Exibe uma mensagem de confirmação de atualização do cadastro


def Consultar_treino():
  while True:
    print("======================")
    print("Gerenciar treino:")
    print("1- Incluir exercício")
    print("2- Alterar exercício")
    print("3- Excluir exercício")
    print("4- Excluir todos os exercícios")
    print("5- Voltar ao menu principal")

    escolher = int(input("Escolha uma opção: "))  # Solicita ao usuário que escolha uma opção do menu

    if escolher == 1:
      if len(treinoAlunos) >= 10:
        print("O treino já possui o máximo de 10 exercícios.")
      else:
        nomeAluno = input("Digite o nome do Aluno: ")  # Solicita o nome do aluno
        nome_exercicio = input("Digite o nome do exercício: ")  # Solicita o nome do exercício
        repeticoes = int(input("Digite o número de repetições: "))  # Solicita o número de repetições
        peso = float(input("Digite o peso utilizado no exercício: "))  # Solicita o peso utilizado no exercício
        exercicio = Exercicio()  # Cria um novo objeto Exercicio
        exercicio.nomeAluno = nomeAluno  # Atribui o nome do aluno ao atributo 'nomeAluno' do objeto exercicio
        exercicio.nomeExercicio = nome_exercicio  # Atribui o nome do exercício ao atributo 'nomeExercicio' do objeto exercicio
        exercicio.numRepeticoes = repeticoes  # Atribui o número de repetições ao atributo 'numRepeticoes' do objeto exercicio
        exercicio.pesoExercicio = peso  # Atribui o peso do exercício ao atributo 'pesoExercicio' do objeto exercicio
        treinoAlunos.append(exercicio)  # Adiciona o objeto exercicio à lista de treinoAlunos
        print("Exercício incluído no treino com sucesso.")

    elif escolher == 2:
      nome_aluno = input("Digite o nome do aluno para atualizar cadastro: ")  # Solicita o nome do aluno para atualização
      treinoEncontrado = []
      for treino in treinoAlunos:
        if treino.nomeAluno == nome_aluno:
          treinoEncontrado.append(treino)
      
      if len(treinoEncontrado) == 0:
        print("Nenhum exercicio encontrado com esse nome de aluno.")
        return

      novo_nome = input("Digite o novo nome: ")  # Solicita o novo nome para atualização
      novo_exercicio = input("Digite o nome de exercicio:  ")  # Solicita o novo nome do exercício para atualização
      novo_numRepeticao = input("Digite o novo numero de repeticao: ")  # Solicita o novo número de repetições para atualização
      novoPeso= input("Digite a novo peso: ")  # Solicita o novo peso para atualização

      for aluno in treinoEncontrado:
        aluno.nome = novo_nome
        aluno.nomeExercicio = novo_exercicio
        aluno.numRepeticoes = float(novo_numRepeticao)
        aluno.pesoExercicio  = float(novoPeso)

      print("Atualizacao feita com sucesso.")

    
    elif escolher == 3:
      nome_aluno = input("Digite o nome do aluno a ser excluído: ")  # Solicita o nome do aluno a ser excluído
      treino_encontrados = []
      for exercicio in treinoAlunos:
        if exercicio.nomeAluno == nome_aluno:
          treino_encontrados.append(exercicio)

      if len(treino_encontrados) == 0:
        print("Nenhum aluno encontrado com esse nome.")
        return

      for aluno in treino_encontrados:
        treinoAlunos.remove(aluno)

      print("Exercicio excluído(s) com sucesso.")


    elif escolher == 4:
      if len(treinoAlunos) == 0:
        print("Nenhum aluno encontrado com esse nome.")
        return

      for i in treinoAlunos:
        treinoAlunos.remove(i)

      print("Todos os treinos foram excluidos com sucesso.")
      print()
      
    elif escolher == 5:
      return

      


def excluir():
  nome_aluno = input("Digite o nome do aluno a ser excluído: ")  # Solicita o nome do aluno a ser excluído
  alunos_encontrados = []  # Cria uma lista para armazenar os alunos encontrados

  # Percorre a lista de cadastro de alunos para encontrar os alunos com o nome informado
  for aluno in cadAlunos:
    if aluno.nome == nome_aluno:
      alunos_encontrados.append(aluno)  # Adiciona o aluno encontrado à lista de alunos encontrados

  if len(alunos_encontrados) == 0:  # Verifica se nenhum aluno foi encontrado com o nome informado
    print("Nenhum aluno encontrado com esse nome.")
    return

  print("Alunos encontrados:")
  # Exibe as informações dos alunos encontrados
  for aluno in alunos_encontrados:
    print("Nome:", aluno.nome)
    print("CPF:", aluno.cpf)
    print("Peso:", aluno.peso)
    print("Altura:", aluno.altura)
    print()

  for aluno in alunos_encontrados:
    cadAlunos.remove(aluno)  # Remove o aluno da lista de cadastro de alunos

  print("Aluno(s) excluído(s) com sucesso.")



def relatório():
  print("Relatorio :")
  print("1- Vizualizar todos os alunos")  # Opção para visualizar todos os alunos
  print("2- Somente Alunos Ativos ")  # Opção para visualizar apenas os alunos ativos
  print("3- Somento Alunos Inativos")  # Opção para visualizar apenas os alunos inativos
  print("0- Voltar ao menu principal")  # Opção para voltar ao menu principal

  escolher = int(input("Escolha uma opção: "))  # Solicita ao usuário para escolher uma opção

  if escolher == 1:
    if len(cadAlunos)==0:
      print("Nenhum aluno encontrado com esse nome.")
    else:
      print()
      print("Lista de todos os Alunos encontrados:")  # Imprime a lista de todos os alunos encontrados
      print()
      for aluno in cadAlunos:
        print("Nome:", aluno.nome)
        print("CPF:", aluno.cpf)
        print("Peso:", aluno.peso)
        print("Altura:", aluno.altura)
        print()

  if escolher == 2:
    comuns = []
    for aluno in cadAlunos:
      for exercicio in treinoAlunos:
        if aluno.nome == exercicio.nomeAluno:  # Verifica se o aluno está presente no treino
          comuns.append(aluno)  # Adiciona o aluno à lista de alunos ativos

    if len(cadAlunos)==0:
      print("Nenhum aluno encontrado com esse nome.")
    else:
        
      print()
      print("Lista de todos os Alunos ativos:")  # Imprime a lista de alunos ativos
      print()
      for aluno in comuns:
        print("Nome:", aluno.nome)
        print("CPF:", aluno.cpf)
        print("Peso:", aluno.peso)
        print("Altura:", aluno.altura)
        print()

  if escolher == 3:
    alunos_nao_comuns = []
    for aluno in cadAlunos:
      encontrado = False
      for exercicio in treinoAlunos :
        if aluno.nome == exercicio.nomeAluno:  # Verifica se o aluno está presente no treino
          encontrado = True
          break
      if not encontrado:  # Se o aluno não estiver presente no treino, considera-o inativo
        alunos_nao_comuns.append(aluno)  # Adiciona o aluno à lista de alunos inativos
      
    if len(cadAlunos)==0:
      print("Nenhum aluno encontrado com esse nome.")
    else:
      print()
      print("Lista de todos os Alunos inativos:")  # Imprime a lista de alunos inativos
      print()
      for aluno in alunos_nao_comuns:
        print("Nome:", aluno.nome)
        print("CPF:", aluno.cpf)
        print("Peso:", aluno.peso)
        print("Altura:", aluno.altura)
        print()

# Codigo principal
while True:
  #   print("                  Bem vindo ")
  print("==================================================")
  print("1- Cadastrar aluno")
  print("2- Gerenciar treino")
  print("3- Consultar aluno")
  print("4- Atualizar cadastro do aluno")
  print("5- Excluir aluno")
  print("6- Relatório de alunos")
  print("0- Para sair ")

  escolher = int(input("Escolha uma opção: "))

  if escolher == 1:
    cadastrar()
  if escolher == 2:
    Consultar_treino()
  if escolher == 3:
    consultar()
  if escolher == 4:
    atualizar()
  if escolher == 5:
    excluir()
  if escolher == 6:
    relatório()
  if escolher == 0:
    break

